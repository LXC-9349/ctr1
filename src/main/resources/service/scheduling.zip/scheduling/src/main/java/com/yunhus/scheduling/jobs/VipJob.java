package com.yunhus.scheduling.jobs;

import com.yunhus.scheduling.commons.annotation.QuartzJob;
import com.yunhus.scheduling.commons.annotation.Trigger;
import com.yunhus.scheduling.modules.client.ClientService;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

/**
 * 功能描述:
 * vip定时任务
 *
 * @author: DoubleLi
 * @date: 2019/5/20 18:31
 */
@Component
@QuartzJob(
        name = "vipJob",
        group = "stat",
        description = "自动分配定时任务",
        valid = true,
        triggers = {
                @Trigger(cron = "0 10 0 ? * *", name = "vipJob", group = "stat", description = "每天凌晨0:10执行")
        }
)
public class VipJob extends QuartzJobBean {

    @Autowired
    private ClientService clientService;

    @Override
    protected void executeInternal(JobExecutionContext context) {
        clientService.expired();
    }

}
