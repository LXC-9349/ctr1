package com.yunhus.scheduling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.yunhus.scheduling.listeners.ApplicationJobEvent;
import com.yunhus.scheduling.listeners.ApplicationJobListener;

@SpringBootApplication
@ComponentScan(basePackages ={"com.yunhus.scheduling"})
@EnableAspectJAutoProxy(exposeProxy=true)
public class SchedulingApplication {

	public static void main(String[] args) {
		SpringApplication application = new SpringApplication(SchedulingApplication.class);
		application.addListeners(new ApplicationJobListener());
		ConfigurableApplicationContext context = application.run(args);
		context.publishEvent(new ApplicationJobEvent(context));
	}

}

