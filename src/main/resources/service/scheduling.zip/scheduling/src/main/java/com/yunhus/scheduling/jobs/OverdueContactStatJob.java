package com.yunhus.scheduling.jobs;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.yunhus.scheduling.commons.CommonUtils;
import com.yunhus.scheduling.commons.annotation.QuartzJob;
import com.yunhus.scheduling.commons.annotation.Trigger;
import com.yunhus.scheduling.commons.jdbc.YunhuJdbcOperations;

/**
 * 说明：逾期未联系量统计
 * @author eric
 * @date 2018年12月29日 下午3:07:05
 */
@Component
@QuartzJob(
	name="overdueContactStatJob", 
	group="stat", description="逾期未联系量统计", 
	valid=false, //暂不开启
	triggers={
		@Trigger(cron="0 0 3 * * ?", name="overdueContactStatJob", group="stat", description="每天凌晨3点更新一次逾期未联系量")
	}
)
public class OverdueContactStatJob extends QuartzJobBean {

	@Resource
	private YunhuJdbcOperations crmJdbc;
	
	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {
		String yesterday = CommonUtils.yesterdayToStr();
		String sql = "select companyId,workerId, '"+yesterday+"' writeDate,count(0) overdueContact from SaleCase where nextContactTime>=? and nextContactTime<?+interval 1 day group by companyId,workerId;";
		List<Map<String, Object>> list = crmJdbc.queryForList(sql, yesterday, yesterday);
		String updateSql = "insert into WorkerService(companyId,workerId,writeDate,overdueContact) values(:companyId,:workerId,:writeDate,:overdueContact) ON DUPLICATE KEY UPDATE  overdueContact=overdueContact+:overdueContact";
		crmJdbc.getNamedParameterJdbcOperations().batchUpdate(updateSql, SqlParameterSourceUtils.createBatch(list.toArray()));
	}

}
