package com.yunhus.scheduling.modules.history.models;

import java.io.Serializable;
import java.util.Date;

public class QuartzHistory implements Serializable {
	private static final long serialVersionUID = 7005987724786677718L;

	private long id;
	private Date fireTime;
	private long runTime;
	private String jobName;
	private String jobGroup;
	private String triggerName;
	private String triggerGroup;
	private int result;
	private String report;

	public transient static final int RESULT_SUCCESS = 1;
	public transient static final int RESULT_FAILED = 2;
	public transient static final int RESULT_MISFIRED = 3;
	public transient static final int RESULT_VETOED = 4;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobGroup() {
		return jobGroup;
	}

	public void setJobGroup(String jobGroup) {
		this.jobGroup = jobGroup;
	}

	public String getTriggerName() {
		return triggerName;
	}

	public void setTriggerName(String triggerName) {
		this.triggerName = triggerName;
	}

	public String getTriggerGroup() {
		return triggerGroup;
	}

	public void setTriggerGroup(String triggerGroup) {
		this.triggerGroup = triggerGroup;
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	public String getReport() {
		return report;
	}

	public void setReport(String report) {
		this.report = report;
	}

	public Date getFireTime() {
		return fireTime;
	}

	public void setFireTime(Date fireTime) {
		this.fireTime = fireTime;
	}

	public long getRunTime() {
		return runTime;
	}

	public void setRunTime(long runTime) {
		this.runTime = runTime;
	}

	public String getNiceRunTime() {
		long runTime = getRunTime();
		if (runTime == 0) {
			return "0����";
		}
		int hours = (int) (runTime / 3600000);
		int minutes = (int) (runTime % 3600000 / 60000);
		int seconds = (int) (runTime % 60000 / 1000);
		int ms = (int) (runTime % 1000);
		StringBuilder sb = new StringBuilder();
		if (hours >= 10) {
			sb.append(hours);
		} else {
			sb.append('0').append(hours);
		}
		sb.append(":");
		if (minutes >= 10) {
			sb.append(minutes);
		} else {
			sb.append('0').append(minutes);
		}
		sb.append(":");
		if (seconds >= 10) {
			sb.append(seconds);
		} else {
			sb.append('0').append(seconds);
		}
		sb.append(".");
		if (ms < 10) {
			sb.append("00").append(ms);
		} else if (ms < 100) {
			sb.append('0').append(ms);
		} else {
			sb.append(ms);
		}
		return sb.toString();
	}
}
