package com.superaicloud.crm.api;

/**
 * 功能描述: 客户回收
 *
 * @author: DoubleLi
 * @date: 2019/5/9 15:43
 */
public interface RecyclingMemberJobService {
    void recyclingMember();
}