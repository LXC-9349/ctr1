package com.yunhus.scheduling.jobs;

import java.util.UUID;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.yunhus.scheduling.commons.annotation.QuartzJob;
import com.yunhus.scheduling.commons.annotation.Trigger;
import com.yunhus.scheduling.modules.client.ClientService;

/**
 * 说明：
 * @author eric
 * @date 2019年3月21日 下午16:39:23
 */
@Component
@QuartzJob(
	name = "dingTalkJob", 
	group = "update", 
	description = "钉钉事件数据处理", 
	valid = false, 
	triggers = { 
		@Trigger(cron = "0 */2 * * * ?", name = "dingTalkJob", group = "update", description = "每2分钟处理一次") 
	}
)
public class DingTalkJob extends QuartzJobBean {

	@Autowired
	private ClientService clientService;
	
	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {
		long beginTime = System.currentTimeMillis();
		System.out.println("dingtalk event begin handle.");
		String requestId = UUID.randomUUID().toString();
		clientService.dingEventHandle(requestId);
		System.out.println("dingtalk event end. sec:" + (System.currentTimeMillis()-beginTime)+"ms");
	}

}
