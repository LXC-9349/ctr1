package com.yunhus.scheduling.commons.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 说明：
 * @author eric
 * @date 2018年12月26日 上午11:41:49
 */
@Target( {ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface Trigger {

	/**cron表达式,如没10秒运行一次 0/10 * * * * ?*/
	String cron();
	String name();
	String group();
	String description() default "";
	String[] datas() default {};
}
