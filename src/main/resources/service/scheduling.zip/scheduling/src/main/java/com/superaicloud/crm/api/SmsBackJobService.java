package com.superaicloud.crm.api;

/**
 * 功能描述: 短信拉取
 *
 * @author: DoubleLi
 * @date: 2019/5/20 18:11
 */
public interface SmsBackJobService {

    /**
     * 短信拉取
     */
    void backSms();
}