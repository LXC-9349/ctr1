package com.yunhus.scheduling.jobs;

import com.yunhus.scheduling.commons.annotation.QuartzJob;
import com.yunhus.scheduling.commons.annotation.Trigger;
import com.yunhus.scheduling.modules.client.ClientService;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

/**
 * 功能描述:
 * 自动分配定时任务
 *
 * @author: DoubleLi
 * @date: 2019/5/7 10:59
 */
@Component
@QuartzJob(
        name = "allotJob",
        group = "stat",
        description = "自动分配定时任务",
        valid = true,
        triggers = {
                @Trigger(cron = "0 30 2 ? * *", name = "allotJob", group = "stat", description = "每天凌晨2:30执行")
        }
)
public class AllotJob extends QuartzJobBean {

    @Autowired
    private ClientService clientService;

    @Override
    protected void executeInternal(JobExecutionContext context) {
        clientService.allot();
    }

}
