package com.yunhus.scheduling.jobs;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.yunhus.scheduling.commons.annotation.QuartzJob;
import com.yunhus.scheduling.commons.annotation.Trigger;
import com.yunhus.scheduling.modules.client.ClientService;

/**
 * 说明：
 * <br>1、检测状态为执行中、当前轮为执行中的任务是否在可运行时间段内，否则暂停任务
 * <br>2、检测状态为执行中、当前轮已完成的任务
 *	<br>2.1 如果任务可运行轮数和当前轮相同，则结束任务
 *	<br>2.2 如果当前轮小于可运行轮数，并且在可运行时段，则启动任务
 */
@Component
@QuartzJob(
		name = "predictCallTaskJob", 
		group = "stat", 
		description = "外呼任务", 
		valid = false,
		triggers = { 
				@Trigger(cron = "0 */2 * * * ?", name = "predictCallTaskJob", group = "stat", description = "外呼任务(每2分钟一次)") 
		}
)
public class PredictCallTaskJob extends QuartzJobBean {
	@Autowired
	private ClientService clientService;
	
	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {
		clientService.roundRobin();
	}
	
}
