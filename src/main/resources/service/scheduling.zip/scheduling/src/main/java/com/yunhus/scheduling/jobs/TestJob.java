package com.yunhus.scheduling.jobs;

import javax.annotation.Resource;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.yunhus.scheduling.commons.annotation.QuartzJob;
import com.yunhus.scheduling.commons.annotation.Trigger;
import com.yunhus.scheduling.commons.jdbc.YunhuJdbcOperations;

/**
 * 说明：
 * @author eric
 * @date 2018年12月25日 下午1:40:06
 */
@Component
@QuartzJob(name="testJob", group="test", description="任务测试", valid=false, datas={"jobName:testjob"}, triggers={
		@Trigger(cron="0/10 * * * * ?", name="testJob", group="test", description="每10秒测试一次", datas={"jobName:testjob1"})
})
public class TestJob extends QuartzJobBean {

	@Resource
	private YunhuJdbcOperations crmJdbc;
	private String jobName;
	
	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {
		int count = crmJdbc.queryForObject("select count(0) from Worker", int.class);
		System.out.println("[jobName:"+jobName+"]" + JSON.toJSONString(context.getJobDetail()) + " " + count);
	}
	
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	
}
