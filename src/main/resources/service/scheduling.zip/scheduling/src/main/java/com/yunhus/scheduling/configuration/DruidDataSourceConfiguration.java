package com.yunhus.scheduling.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcOperations;

import com.alibaba.druid.pool.DruidDataSource;
import com.yunhus.scheduling.commons.jdbc.YunhuJdbcTemplate;

/**
 * 说明：druid数据源配置
 * @author eric
 * @date 2018年12月24日 上午10:41:55
 */
@Configuration
public class DruidDataSourceConfiguration {

	@ConfigurationProperties(prefix="spring.datasource")
	@Bean(name="quartzDataSource")
	public DataSource dataSource(){	
		return new DruidDataSource();
	}
	
	@ConfigurationProperties(prefix="spring.datasource.crm")
	@Bean(name="crmDataSource")
	public DataSource crmDataSource(){	
		return new DruidDataSource();
	}
	
	@Bean(name="quartzJdbc")
	public JdbcOperations jdbcOperations(@Qualifier("quartzDataSource") DataSource dataSource){
		return new YunhuJdbcTemplate(dataSource);
	}
	
	@Bean(name="crmJdbc")
	public JdbcOperations crmJdbcOperations(@Qualifier("crmDataSource") DataSource dataSource){
		return new YunhuJdbcTemplate(dataSource);
	}
}
