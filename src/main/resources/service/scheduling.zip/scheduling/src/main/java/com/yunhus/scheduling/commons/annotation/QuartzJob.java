package com.yunhus.scheduling.commons.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 说明：Job标记注解
 * @author eric
 * @date 2018年12月26日 上午10:34:38
 */
@Target( {ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface QuartzJob {

	String name();
	String group();
	String description() default "";
	String[] datas() default {};
	Trigger[] triggers() default {};
	/**是否生效，设置为false，则会把已经在运行的任务删除,但是不是删除JobDetail*/
	boolean valid() default true;
}
