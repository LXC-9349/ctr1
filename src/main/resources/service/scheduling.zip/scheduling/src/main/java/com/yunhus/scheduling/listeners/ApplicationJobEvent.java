package com.yunhus.scheduling.listeners;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;

import com.yunhus.scheduling.commons.annotation.QuartzJob;
import com.yunhus.scheduling.commons.annotation.Trigger;

/**
 * 说明：
 * @author eric
 * @date 2018年12月26日 上午10:11:30
 */
public class ApplicationJobEvent extends ApplicationEvent {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5305858221654565387L;
	
	private ApplicationContext applicationContext;

	public ApplicationJobEvent(Object source) {
		super(source);
		this.applicationContext = (ApplicationContext) source;
	}
	
	public void registerJob(){
		Scheduler scheduler = applicationContext.getBean("scheduler", Scheduler.class);
		Map<String, Object> beanNames = applicationContext.getBeansWithAnnotation(QuartzJob.class);
		Set<Entry<String, Object>> set = beanNames.entrySet();
		for (Iterator<Entry<String, Object>> it = set.iterator();it.hasNext();) {
			Entry<String, Object> entry = it.next();
			process(entry.getValue(), scheduler);
		}
	}
	
	private void process(Object object, Scheduler scheduler){
		if(object == null) return;
		if(!(object instanceof Job)) return;
		QuartzJob quartzJob = object.getClass().getAnnotation(QuartzJob.class);
		if(quartzJob == null) return;
		if(!quartzJob.valid()) {
			List<TriggerKey> triggerKeys = new ArrayList<TriggerKey>();
			if(quartzJob.triggers() != null && quartzJob.triggers().length > 0){
				for (int i = 0, len = quartzJob.triggers().length; i < len; i++) {
					Trigger trigger = quartzJob.triggers()[i];
					triggerKeys.add(new TriggerKey(trigger.name(), trigger.group()));
				}
			}
			if(triggerKeys.size() > 0){
				try {
					scheduler.unscheduleJobs(triggerKeys);
				} catch (SchedulerException e) {
					e.printStackTrace();
				}
			}
			return;
		}
		Job jobObject = (Job)object;
		try {
			JobBuilder builder = JobBuilder.newJob(jobObject.getClass())
					.storeDurably()
					.withIdentity(quartzJob.name(), quartzJob.group())
					.withDescription(quartzJob.description());
			if(quartzJob.datas() != null && quartzJob.datas().length > 0){
				for (int i = 0, len=quartzJob.datas().length; i < len; i++) {
					String[] data = StringUtils.split(quartzJob.datas()[i], ":");
					if(data.length > 1) builder.usingJobData(data[0], data[1]);
				}
			}
			JobDetail joDetail = builder.build();
			Set<CronTrigger> triggers = new HashSet<CronTrigger>(quartzJob.triggers().length);
			if(quartzJob.triggers() != null && quartzJob.triggers().length > 0){
				for (int i = 0, len = quartzJob.triggers().length; i < len; i++) {
					Trigger trigger = quartzJob.triggers()[i];
							CronScheduleBuilder scheduleBuilder = CronScheduleBuilder.cronSchedule(trigger.cron());
					TriggerBuilder<CronTrigger> triggerBuilder = TriggerBuilder.newTrigger()
							.withSchedule(scheduleBuilder)
							.withIdentity(trigger.name(), trigger.group());
					if(trigger.datas() != null && trigger.datas().length > 0){
						for (int j = 0, length=trigger.datas().length; i < length; i++) {
							String[] data = StringUtils.split(trigger.datas()[j], ":");
							if(data.length > 1) triggerBuilder.usingJobData(data[0], data[1]);
						}
					}
					CronTrigger cronTrigger = triggerBuilder.build();
					triggers.add(cronTrigger);
				}
			}
			if(!triggers.isEmpty()){
				scheduler.scheduleJob(joDetail, triggers, true);
			}else{
				scheduler.addJob(joDetail, true);
			}
		} catch (SchedulerException e) {
			e.printStackTrace();
		}
	}

}
