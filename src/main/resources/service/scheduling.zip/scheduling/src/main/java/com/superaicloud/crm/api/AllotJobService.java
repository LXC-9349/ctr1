package com.superaicloud.crm.api;

/**
 * 功能描述: 自动分配定时任务
 *
 * @author: DoubleLi
 * @date: 2019/5/5 14:44
 */
public interface AllotJobService {
    void allot();
}