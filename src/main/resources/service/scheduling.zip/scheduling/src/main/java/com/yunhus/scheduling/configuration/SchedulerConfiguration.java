package com.yunhus.scheduling.configuration;

import java.util.Properties;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.quartz.Scheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.yunhus.scheduling.listeners.QuatzHistoryListener;

/**
 * 说明：
 * @author eric
 * @date 2018年12月25日 上午11:30:37
 */
@Configuration
public class SchedulerConfiguration {

	@Autowired
	private SpringBeanAutowireJobFactory jobFactory;
	@Autowired
	private QuatzHistoryListener quatzHistoryListener;
	@Resource
	private DataSource quartzDataSource;
	
	@Bean(name="schedulerFactoryBean")
	public SchedulerFactoryBean schedulerFactoryBean() throws Exception{
		PropertiesFactoryBean propertiesFactoryBean = new PropertiesFactoryBean();
		propertiesFactoryBean.setLocation(new ClassPathResource("quartz.properties"));
		propertiesFactoryBean.afterPropertiesSet();
		SchedulerFactoryBean schedulerFactoryBean = new SchedulerFactoryBean();
		Properties pro = propertiesFactoryBean.getObject();
		schedulerFactoryBean.setOverwriteExistingJobs(true);
		schedulerFactoryBean.setAutoStartup(true);
		schedulerFactoryBean.setQuartzProperties(pro);
		schedulerFactoryBean.setJobFactory(jobFactory);
		schedulerFactoryBean.setNonTransactionalDataSource(quartzDataSource);
		schedulerFactoryBean.setGlobalTriggerListeners(quatzHistoryListener);
        return schedulerFactoryBean;
	}
	
	@Bean(name="scheduler")
	public Scheduler scheduler(@Qualifier("schedulerFactoryBean") SchedulerFactoryBean factoryBean){
		return factoryBean.getScheduler();
	}
	
}
