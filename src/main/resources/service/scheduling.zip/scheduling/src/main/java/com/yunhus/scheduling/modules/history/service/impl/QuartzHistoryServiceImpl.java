package com.yunhus.scheduling.modules.history.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.stereotype.Service;

import com.yunhus.scheduling.commons.CommonUtils;
import com.yunhus.scheduling.commons.PageHolder;
import com.yunhus.scheduling.commons.jdbc.YunhuJdbcOperations;
import com.yunhus.scheduling.modules.history.models.QuartzHistory;
import com.yunhus.scheduling.modules.history.service.QuartzHistoryService;

@Service("quartzHistoryService")
public class QuartzHistoryServiceImpl implements QuartzHistoryService {

	private String tableName = "QUTZ_HISTORY";
	@Resource
	private YunhuJdbcOperations quartzJdbc;

	private BeanPropertyRowMapper<QuartzHistory> rowMapper = BeanPropertyRowMapper.newInstance(QuartzHistory.class);

	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#insert(com.yunhus.scheduling.modules.history.models.QuartzHistory)
	 */
	public void insert(QuartzHistory history) {
		final String sql = "insert into "
				+ tableName
				+ " (fireTime,runTime,jobName,jobGroup,triggerName,triggerGroup,result,report)"
				+ " values"
				+ " (:fireTime,:runTime,:jobName,:jobGroup,:triggerName,:triggerGroup,:result,:report)";
		quartzJdbc.getNamedParameterJdbcOperations().update(sql, new BeanPropertySqlParameterSource(history));
	}

	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#select(long)
	 */
	public QuartzHistory select(long id) {
		final String sql = "select * from " + tableName + " where id=?";
		return quartzJdbc.queryForObject(sql, rowMapper, id);
	}

	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#select(java.util.Date, java.util.Date)
	 */
	public List<QuartzHistory> select(Date startDate, Date endDate) {
		final String sql = "select * from " + tableName + " where fireTime>=? and fireTime<?"
				+ " order by fireTime asc";
		return quartzJdbc.query(sql, rowMapper, startDate, endDate);
	}

	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#select(java.lang.String, java.lang.String, java.util.Date, java.util.Date)
	 */
	public List<QuartzHistory> select(String jobGroup, String jobName, Date startDate, Date endDate) {
		final String sql = "select * from " + tableName
				+ " where jobGroup=? and jobName=? fireTime>=? and fireTime<?"
				+ " order by fireTime asc";
		return quartzJdbc.query(sql, rowMapper, jobGroup, jobName, startDate, endDate);
	}

	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#select(int, java.util.Date, java.util.Date)
	 */
	public List<QuartzHistory> select(int type, Date startDate, Date endDate) {
		final String sql = "select * from " + tableName
				+ " where result=? and fireTime>=? and fireTime<?" + " order by fireTime asc";
		return quartzJdbc.query(sql, rowMapper, type, startDate, endDate);
	}

	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#select(int, java.lang.String, java.lang.String, java.util.Date, java.util.Date)
	 */
	public List<QuartzHistory> select(int type, String jobGroup, String jobName, Date startDate,
			Date endDate) {
		final String sql = "select * from " + tableName
				+ " where jobGroup=? and jobName=? and result=? and fireTime>=? and fireTime<?"
				+ " order by fireTime asc";
		return quartzJdbc.query(sql, rowMapper, jobGroup, jobName, type, startDate, endDate);
	}

	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#select(com.yunhus.scheduling.commons.PageHolder)
	 */
	public void select(PageHolder<QuartzHistory> pageHolder) {
		final String sql = "select * from " + tableName + " order by id desc limit ?,?";
		pageHolder.setList(quartzJdbc.query(sql, rowMapper, pageHolder.getRowOffset(), pageHolder
				.getPageSize()));
		final String countSql = "select count(0) from " + tableName;
		pageHolder.setRowCount(quartzJdbc.queryForObject(countSql, Long.class));
	}

	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#selectNotSuccess(com.yunhus.scheduling.commons.PageHolder)
	 */
	public void selectNotSuccess(PageHolder<QuartzHistory> pageHolder) {
		final String sql = "select * from " + tableName
				+ " where result>1 order by id desc limit ?,?";
		pageHolder.setList(quartzJdbc.query(sql, rowMapper, pageHolder.getRowOffset(), pageHolder
				.getPageSize()));
		final String countSql = "select count(0) from " + tableName + " where result>1";
		pageHolder.setRowCount(quartzJdbc.queryForObject(countSql, Long.class));
	}

	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#select(java.lang.String, java.lang.String, com.yunhus.scheduling.commons.PageHolder)
	 */
	public void select(String group, String name, PageHolder<QuartzHistory> pageHolder) {
		final String sql = "select * from " + tableName
				+ " where jobGroup=? and jobName=? order by id desc limit ?,?";
		pageHolder.setList(quartzJdbc.query(sql, rowMapper, group, name, pageHolder.getRowOffset(),
				pageHolder.getPageSize()));
		final String countSql = "select count(0) from " + tableName + " where jobGroup=? and jobName=?";
		pageHolder.setRowCount(quartzJdbc.queryForObject(countSql, Long.class, group, name));
	}

	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#selectNotSuccess(java.lang.String, java.lang.String, com.yunhus.scheduling.commons.PageHolder)
	 */
	public void selectNotSuccess(String group, String name, PageHolder<QuartzHistory> pageHolder) {
		final String sql = "select * from " + tableName
				+ " where jobGroup=? and jobName=? and result>1 order by id desc limit ?,?";
		pageHolder.setList(quartzJdbc.query(sql, rowMapper, group, name, pageHolder.getRowOffset(),
				pageHolder.getPageSize()));
		final String countSql = "select count(0) from " + tableName
				+ " where jobGroup=? and jobName=? and result>1";
		pageHolder.setRowCount(quartzJdbc.queryForObject(countSql, Long.class, group, name));
	}
	
	
	/* (non-Javadoc)
	 * @see com.yunhus.scheduling.modules.history.service.impl.QuartzHistoryService#getMisfiredJobInOneMiniute()
	 */
	public int getMisfiredJobInOneMiniute() {
		Date now = new Date();		
		Date misBeginDate = CommonUtils.add(now,Calendar.MINUTE ,-1);		
		final String sql_mifiredJob = " select count(1) from QUTZ_HISTORY where fireTime > ?  and  fireTime < ? and result = "+QuartzHistory.RESULT_MISFIRED+";" ;
		return quartzJdbc.queryForObject(sql_mifiredJob, int.class, misBeginDate ,now);
	}
}
