package com.yunhus.scheduling.jobs;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.yunhus.scheduling.commons.annotation.QuartzJob;
import com.yunhus.scheduling.commons.annotation.Trigger;
import com.yunhus.scheduling.modules.client.ClientService;

/**
 * 说明：
 * @author eric
 * @date 2019年1月2日 下午2:45:59
 */
@Component
@QuartzJob(
	name = "chatJob", 
	group = "chat", 
	description = "聊天定时任务", 
	valid = false,
	triggers = { 
		@Trigger(cron = "0 */5 * * * ?", name = "chatJob", group = "chat", description = "每5分钟运行一次") 
	}
)
public class ChatJob extends QuartzJobBean {

	@Autowired
	private ClientService clientService;
	
	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {
		String result = clientService.detectChatStatus();
		System.out.println(result);
	}

}
