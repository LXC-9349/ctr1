package com.yunhus.scheduling.modules.history.service;

import java.util.Date;
import java.util.List;

import com.yunhus.scheduling.commons.PageHolder;
import com.yunhus.scheduling.modules.history.models.QuartzHistory;

/**
 * 说明：
 * @author eric
 * @date 2018年12月25日 上午11:24:59
 */
public interface QuartzHistoryService {

	public abstract void insert(QuartzHistory history);

	public abstract QuartzHistory select(long id);

	public abstract List<QuartzHistory> select(Date startDate, Date endDate);

	public abstract List<QuartzHistory> select(String jobGroup, String jobName,
			Date startDate, Date endDate);

	public abstract List<QuartzHistory> select(int type, Date startDate,
			Date endDate);

	public abstract List<QuartzHistory> select(int type, String jobGroup,
			String jobName, Date startDate, Date endDate);

	public abstract void select(PageHolder<QuartzHistory> pageHolder);

	public abstract void selectNotSuccess(PageHolder<QuartzHistory> pageHolder);

	public abstract void select(String group, String name,
			PageHolder<QuartzHistory> pageHolder);

	public abstract void selectNotSuccess(String group, String name,
			PageHolder<QuartzHistory> pageHolder);

	public abstract int getMisfiredJobInOneMiniute();

}