package com.yunhus.scheduling.commons;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 用于保存分页信息和负责分页逻辑运算的类。<br />
 * <b>这个类不是线程安全的</b>
 * </p>
 * 
 * 使用方法： <br />
 * PageHolder&lt;Person&gt; pList=new PageHolder&lt;Person&gt;();<br />
 * pHolder.setPageIndex();//当前页的页码<br />
 * pHolder.setPageSize();//每页的大小<br />
 * <br />
 * pHolder.setRowCount(dao.count(...));//获取数据库里的总记录数<br />
 * pHolder.setList(dao.list(...));//从数据库获取当前页的数据<br />
 * <br />
 * pHolder.addParam("category","5");//设置其他的url参数<br />
 * request.setAttribute("pageHolder",pHolder);//放入request<br />
 * 至此，PageHolder的数据填充就完成了，下一步是在JSP页面内做显示<br />
 * 
 * @author Jonney
 */
public class PageHolder<E> implements Serializable {

	private static final long serialVersionUID = -5245410061872947316L;

	protected static final transient int DEFAULT_MAX_PAGE_SIZE = 30000;

	protected static final transient int DEFAULT_PAGE_SIZE = 25;

	protected static final transient String DEFAULT_PARAM_ENCODING = "utf-8";

	/**
	 * 当前页码
	 */
	private int pageIndex;

	/**
	 * 页大小
	 */
	private int pageSize = DEFAULT_PAGE_SIZE;

	/**
	 * 页大小是否可以重设
	 */
	private boolean pageSizeResetAble = true;

	/**
	 * 最大页大小
	 */
	private int maxPageSize = DEFAULT_MAX_PAGE_SIZE;
	/**
	 * 是否最后一页
	 */
	private boolean lastPage = false;
	/**
	 * 页数量
	 */
	private int pageCount;

	/**
	 * 行数量
	 */
	private long rowCount;

	/**
	 * 数据列表
	 */
	private List<E> list;

	private String paramEncoding = DEFAULT_PARAM_ENCODING;

	private final List<Param> paramList = new ArrayList<Param>();

	private String pageIndexKey = "pageHolder.pageIndex";

	private final String rowCountKey = "pageHolder.rowCount";

	/**
	 * @param pageSize
	 *            页大小
	 */
	public PageHolder(int pageSize) {
		this(pageSize, false);
	}

	/**
	 * @param pageSize
	 *            页大小
	 */
	public PageHolder(int pageSize, boolean pageSizeResetAble) {
		this.pageSize = pageSize;
		this.pageSizeResetAble = pageSizeResetAble;
	}

	/**
	 * @param pageIndex
	 *            当前页码
	 * @param pageSize
	 *            页大小
	 */
	public PageHolder(int pageIndex, int pageSize) {
		this.pageIndex = pageIndex < 1 ? 1 : pageIndex;
		this.pageSize = pageSize;
	}

	/**
	 * @return pageCount
	 */
	public int getPageCount() {
		return pageCount;
	}

	/**
	 * @return rowCount
	 */
	public long getRowCount() {
		return rowCount;
	}

	/**
	 * @param rowCount
	 *            要设置的 rowCount
	 * @throws Exception
	 */
	public void setRowCount(long rowCount) {
		this.rowCount = rowCount;
		int pageSize = getPageSize();
		try {
			pageCount = (int) ((rowCount - 1 + pageSize) / pageSize);
		} catch (ArithmeticException e) {
			throw new RuntimeException("Property pageSize has not set into PageHolder.");
		}
		if (pageCount > 0 && pageIndex > pageCount) {
			pageIndex = pageCount;
		}
	}

	/**
	 * @return pageIndex
	 */
	public int getPageIndex() {
		return pageIndex < 1 ? 1 : pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public void setPageSize(int pageSize) {
		if (pageSizeResetAble) {
			this.pageSize = pageSize;
		}
	}

	/**
	 * @return pageSize
	 */
	public int getPageSize() {
		if (pageSize > maxPageSize) {
			return maxPageSize;
		} else {
			return pageSize;
		}
	}

	public int getMaxPageSize() {
		return maxPageSize;
	}

	public void setMaxPageSize(int maxPageSize) {
		this.maxPageSize = maxPageSize;
	}

	/**
	 * @return list
	 */
	public List<E> getList() {
		return list;
	}

	/**
	 * @param list
	 *            要设置的 list
	 */
	public void setList(List<E> list) {
		this.list = list;
	}

	/**
	 * @return paramEncoding
	 */
	public String getParamEncoding() {
		return paramEncoding;
	}

	/**
	 * @param paramEncoding
	 *            要设置的 paramEncoding
	 */
	public void setParamEncoding(String paramEncoding) {
		this.paramEncoding = paramEncoding;
	}

	/**
	 * 
	 * @param key
	 * @param value
	 */
	public void addParam(String key, Object value) {
		Param p = new Param(key, value == null ? "" : value);
		boolean bl = true;
		for (Param m : paramList) {
			if (m.key.equals(p.key)) {
				bl = false;
				break;
			}

		}
		if (bl) {
			paramList.add(p);
		}

	}

	/**
	 * 
	 * @return
	 */
	public String getParams() {
		StringBuilder sb = new StringBuilder();
		try {
			for (Param p : paramList) {
				if (p.value.getClass().isArray()) {
					String[] values = (String[]) p.value;
					for (String v : values) {
						sb.append('&');
						sb.append(URLEncoder.encode(p.key, paramEncoding));
						sb.append('=');
						sb.append(URLEncoder.encode(v, paramEncoding));
					}
				} else {
					sb.append('&');
					sb.append(URLEncoder.encode(p.key, paramEncoding));
					sb.append('=');
					sb.append(URLEncoder.encode(p.value.toString(), paramEncoding));
				}
			}
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException(e);
		}
		return sb.toString();
	}

	/**
	 * 取当前页的第一行数据在数据库中的行号，在操作数据库的时候有用
	 * 
	 * @return
	 */
	public int getRowOffset() {
		return (getPageIndex() - 1) * getPageSize();
	}

	/**
	 * 是否第一页
	 * 
	 * @return
	 */
	public boolean isFirstPage() {
		return getPageIndex() <= 1 ? true : false;
	}

	/**
	 * 是否最后一页
	 * 
	 * @return
	 */
	public boolean isLastPage() {
		return lastPage ? lastPage :(getPageIndex() >= getPageCount() ? true : false);
	}

	public String getPageIndexKey() {
		return pageIndexKey;
	}

	public void setPageIndexKey(String pageIndexKey) {
		this.pageIndexKey = pageIndexKey;
	}

	private class Param {

		public String key;

		public Object value;

		public Param(String key, Object value) {
			this.key = key;
			this.value = value;
		}
	}

	public static void main(String[] args) {
		PageHolder<String> p = new PageHolder<String>(3, 4);
		p.addParam("1", "中文");
		p.addParam("2", "22");
		p.addParam("3", "33");
		System.out.println(p.getParams());
		p.setRowCount(40);
		System.out.println(p.getPageCount());
	}

	public String getRowCountKey() {
		return rowCountKey;
	}

	public boolean getPageSizeResetAble() {
		return pageSizeResetAble;
	}

	public void setPageSizeResetAble(boolean pageSizeResetAble) {
		this.pageSizeResetAble = pageSizeResetAble;
	}

	public void setLastPage(boolean lastPage) {
		this.lastPage = lastPage;
	}
	
	
}
