package com.yunhus.scheduling.jobs;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.yunhus.scheduling.commons.annotation.QuartzJob;
import com.yunhus.scheduling.commons.annotation.Trigger;
import com.yunhus.scheduling.modules.client.ClientService;

/**
 * 说明：
 * @author eric
 * @date 2019年1月2日 下午5:19:41
 */
@Component
@QuartzJob(
		name = "repertoryStatJob", 
		group = "stat", 
		description = "库存报表统计", 
		valid = false,
		triggers = { 
				@Trigger(cron = "0 0 0/1 * * ?", name = "repertoryStatJob", group = "stat", description = "库存报表统计(每1小时统计一次)") 
		}
)
public class RepertoryStatJob extends QuartzJobBean {

	@Autowired
	private ClientService clientService;
	
	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {
		clientService.repertoryStat();
	}

}
