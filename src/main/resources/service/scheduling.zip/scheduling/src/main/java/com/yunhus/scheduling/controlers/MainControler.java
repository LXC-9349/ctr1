package com.yunhus.scheduling.controlers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 说明：
 * @author eric
 * @date 2018年12月25日 下午2:59:05
 */
@Controller
public class MainControler {

	@RequestMapping({"/"})
	public String index(){
		return "index";
	}
}
