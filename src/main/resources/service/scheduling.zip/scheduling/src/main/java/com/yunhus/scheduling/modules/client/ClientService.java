package com.yunhus.scheduling.modules.client;

import com.alibaba.dubbo.config.annotation.Reference;
import com.superaicloud.crm.api.AllotJobService;
import com.superaicloud.crm.api.RecyclingMemberJobService;
import com.superaicloud.crm.api.SmsBackJobService;
import com.superaicloud.crm.api.VipService;
import com.yunhus.crm.api.*;
import org.springframework.stereotype.Service;

/**
 * 说明：
 *
 * @author eric
 * @date 2019年1月2日 下午3:22:02
 */
@Service
public class ClientService {

    @Reference(timeout = 10000)
    private ChatService chatService;
    @Reference(timeout = 10000)
    private StatService statService;
    @Reference(timeout = 10000)
    private TrackService trackService;
    @Reference(timeout = 10000)
    private PredictcallJobService predictcallJobService;
    @Reference(timeout = 120000)
    private DingService dingService;
    @Reference(timeout = 120000)
    private AllotJobService allotJobService;
    @Reference(timeout = 120000)
    private RecyclingMemberJobService recyclingMemberJobService;
    @Reference(timeout = 120000)
    private VipService vipService;
    @Reference(timeout = 120000)
    private SmsBackJobService smsBackJobService;

    public String detectChatStatus() {
        return chatService.detectChatStatus();
    }

    public void repertoryStat() {
        statService.repertoryStat();
    }

    public void trackRecord() {
        trackService.trackRecord();
    }

    public void roundRobin() {
        predictcallJobService.roundRobin();
    }

    public void dingEventHandle(String requestId) {
        dingService.process(requestId);
    }

    public void allot() {
        allotJobService.allot();
    }

    public void recycling() {
        recyclingMemberJobService.recyclingMember();
    }

    public void expired() {
        vipService.expired();
    }

    public void backSms() {
        smsBackJobService.backSms();
    }
}
