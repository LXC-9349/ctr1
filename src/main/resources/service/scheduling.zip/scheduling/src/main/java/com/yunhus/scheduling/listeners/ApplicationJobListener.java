package com.yunhus.scheduling.listeners;

import org.springframework.context.ApplicationListener;

/**
 * 说明：
 * @author eric
 * @date 2018年12月26日 上午10:17:06
 */
public class ApplicationJobListener implements ApplicationListener<ApplicationJobEvent> {

	public void onApplicationEvent(ApplicationJobEvent event) {
		event.registerJob();
	}

}
