package com.yunhus.scheduling.listeners;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;

import javax.annotation.Resource;

import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;
import org.quartz.Trigger;
import org.quartz.Trigger.CompletedExecutionInstruction;
import org.quartz.TriggerListener;
import org.springframework.stereotype.Component;

import com.yunhus.scheduling.modules.history.models.QuartzHistory;
import com.yunhus.scheduling.modules.history.service.QuartzHistoryService;

@Component
public class QuatzHistoryListener implements JobListener, TriggerListener {

	@Resource
	private QuartzHistoryService quartzHistoryService;


	public void jobToBeExecuted(JobExecutionContext context) {
		// do nothing
	}

	public void jobWasExecuted(JobExecutionContext context, JobExecutionException jobException) {
		Trigger trigger = context.getTrigger();
		JobDetail jobDetail = context.getJobDetail();

		QuartzHistory history = new QuartzHistory();
		history.setFireTime(context.getFireTime());
		history.setRunTime(context.getJobRunTime());
		history.setJobGroup(jobDetail.getKey().getGroup());
		history.setJobName(jobDetail.getKey().getName());
		history.setTriggerGroup(trigger.getKey().getGroup());
		history.setTriggerName(trigger.getKey().getName());

		if (jobException != null) {
			history.setResult(QuartzHistory.RESULT_FAILED);
			StringBuilder report = new StringBuilder();
			JobDataMap dataMap = context.getMergedJobDataMap();
			report.append("mergedJobDataMap:\r\n");
			for (Object key : dataMap.keySet()) {
				report.append(key).append(" = ").append(dataMap.get(key));
				report.append("\r\n");
			}
			report.append("\r\n\r\n");
			StringWriter stackTrace = new StringWriter();
			jobException.printStackTrace(new PrintWriter(stackTrace));
			report.append("stackTrace:\r\n").append(stackTrace);
			history.setReport(report.toString());			
		} else {
			history.setResult(QuartzHistory.RESULT_SUCCESS);
			StringBuilder report = new StringBuilder();
			report.append("result:\r\n").append(context.getResult());
			history.setReport(report.toString());
		}
		
		try {
			quartzHistoryService.insert(history);
		} catch (Exception e) {
			System.out.println("############################# insert quartz history failed #############################");
			e.printStackTrace();
			System.out.println("########################################################################################");
		}
	}

	public void jobExecutionVetoed(JobExecutionContext context) {
		Trigger trigger = context.getTrigger();
		JobDetail jobDetail = context.getJobDetail();

		QuartzHistory history = new QuartzHistory();
		history.setFireTime(context.getFireTime());
		history.setRunTime(context.getJobRunTime());
		history.setJobGroup(jobDetail.getKey().getGroup());
		history.setJobName(jobDetail.getKey().getName());
		history.setTriggerGroup(trigger.getKey().getGroup());
		history.setTriggerName(trigger.getKey().getName());
		history.setResult(QuartzHistory.RESULT_VETOED);
		quartzHistoryService.insert(history);
	}

	public void triggerComplete(Trigger trigger, JobExecutionContext context,
			int triggerInstructionCode) {
		// do nothing
	}

	public void triggerFired(Trigger trigger, JobExecutionContext context) {
		
	}

	public void triggerMisfired(Trigger trigger) {
		QuartzHistory history = new QuartzHistory();
		history.setFireTime(new Date());
		history.setRunTime(0);
		history.setJobGroup(trigger.getJobKey().getGroup());
		history.setJobName(trigger.getJobKey().getName());
		history.setTriggerGroup(trigger.getKey().getGroup());
		history.setTriggerName(trigger.getKey().getName());
		history.setResult(QuartzHistory.RESULT_MISFIRED);
		quartzHistoryService.insert(history);
	}

	public boolean vetoJobExecution(Trigger trigger, JobExecutionContext context) {
		return false;
	}

	public void triggerComplete(Trigger trigger, JobExecutionContext context,
			CompletedExecutionInstruction triggerInstructionCode) {
		
	}

	public String getName() {
		return "quatzHistoryListener";
	}

}
