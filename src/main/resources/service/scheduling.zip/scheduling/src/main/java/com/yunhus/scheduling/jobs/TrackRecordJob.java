package com.yunhus.scheduling.jobs;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.yunhus.scheduling.commons.annotation.QuartzJob;
import com.yunhus.scheduling.commons.annotation.Trigger;
import com.yunhus.scheduling.modules.client.ClientService;

/**
 * 说明：
 * @author eric
 * @date 2019年1月2日 下午5:19:41
 */
@Component
@QuartzJob(
		name = "trackRecordJob", 
		group = "update", 
		description = "今日与遗留跟进资源整理", 
		valid = false,
		triggers = { 
				@Trigger(cron = "0 0 3 * * ?", name = "trackRecordJob", group = "update", description = "今日与遗留跟进资源整理(每凌晨3点运算一次)") 
		}
)
public class TrackRecordJob extends QuartzJobBean {

	@Autowired
	private ClientService clientService;
	
	@Override
	protected void executeInternal(JobExecutionContext context)
			throws JobExecutionException {
		clientService.trackRecord();
	}

}
