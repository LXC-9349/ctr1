package com.yunhus.scheduling;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSON;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SchedulingApplicationTests {

	@Resource
	private JdbcOperations crmJdbc;
	
	@Test
	public void contextLoads() {
		List<Map<String, Object>> result = crmJdbc.queryForList("select * from Worker where workerId=8888");
		System.out.println(JSON.toJSONString(result)
				);
	}

}

