调度系统说明
============
任务开发的两个注解`QuartzJob`   `Trigger`说明
--------
QuartzJob
```java
@Target( {ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface QuartzJob {

	String name();
	String group();
	String description() default "";
	/**数据项，可配置多个，如{"jobName:testJob","xxx:xxx"}*/
	String[] datas() default {};
	/**配置触发器，具体见Trigger注解*/
	Trigger[] triggers() default {};
	/**是否生效，设置为false，则会把已经在运行的任务删除,但是不是删除JobDetail*/
	boolean valid() default true;
}
```
Trigger
```java
@Target( {ElementType.TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface Trigger {

	/**cron表达式,如没10秒运行一次 0/10 * * * * ?*/
	String cron();
	String name();
	String group();
	String description() default "";
	String[] datas() default {};
}
```