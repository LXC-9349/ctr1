#!/bin/bash

#-------------------------------------------------------------------
#    Mb  Bootstrap Script
#-------------------------------------------------------------------

# find Mb home.
CURR_DIR=`pwd`
cd `dirname "$0"`/..
RESV_HOME=`pwd`
cd $CURR_DIR

if [ -z "$RESV_HOME" ] ; then
    echo
    echo Must set RESV_HOME
    echo
    exit 1
fi

pid=`ps -ef | grep scheduling | grep java | grep -v "start" | awk -F " " '{print $2}'`
if [ -z "$pid" ]; then
    echo " not runing"
else
    echo "killing process : $pid"
    echo "scheduling stop..."
    kill -9 $pid
fi
sleep 1
echo "restart ... "
sh $RESV_HOME/bin/start.sh start &
